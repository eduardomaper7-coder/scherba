CLÍNICA DENTAL SCHERBA — NUEVA WEB

Contenido
- Diseño completo responsive en HTML/CSS/JS.
- 31 páginas: inicio, tratamientos, clínica, contacto, blog, fichas y legales.
- Identidad basada en el azul corporativo extraído del cartel: #2D919C.
- Logotipo recortado y preparado con fondo transparente.
- Sin analítica, cookies publicitarias ni dependencias de JavaScript externas.

Antes de publicar
1. Sustituir TU-DOMINIO.es en sitemap.xml y robots.txt.
2. Completar NIF/CIF, titular, registro sanitario, colegio profesional y correo en las páginas legales.
3. Confirmar horarios y añadirlos en index.html/contacto.html.
4. Revisar la lista real de tratamientos y ajustar cualquier servicio que la clínica no ofrezca.
5. Añadir fotografías reales del equipo y las instalaciones si se desea.
6. Verificar teléfono y dirección: 922 209 262 · C. de Fernández Navarro, 35, 38003 Santa Cruz de Tenerife.

Vista previa
Abrir index.html en un navegador o servir la carpeta con:
python -m http.server 8000
